"""
LangFlow integration layer for AI Grant Funding Finder.

This package provides:
  - workflow.py           Python bridge that maps LangFlow agent routes to the
                          existing src/agents/* implementations.
  - streamlit_integration.py  Streamlit page that drives the workflow from the UI.
"""
