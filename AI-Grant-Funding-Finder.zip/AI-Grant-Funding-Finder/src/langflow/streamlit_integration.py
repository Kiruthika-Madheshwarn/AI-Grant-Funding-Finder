"""
LangFlow Workflow — Streamlit Integration Page
================================================
Renders a dedicated "LangFlow Workflow" page in the AI Grant Funding Finder
Streamlit app.  All four agent routes are accessible from a single page,
giving users a clear view of how the LangFlow workflow is structured and
letting them invoke each agent interactively.

Import this module and call ``render()`` from app.py.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import streamlit as st

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Grant catalogue helper (mirrors app.py)
# ---------------------------------------------------------------------------

GRANT_OPTIONS = {
    "grant_001": "NSF SBIR Phase I",
    "grant_002": "NIH R01 Research Grant",
    "grant_003": "USDA Rural Business Development",
    "grant_004": "Gates Grand Challenges Explorations",
    "grant_005": "EPA Environmental Justice",
    "grant_006": "Ford Foundation BUILD",
    "grant_007": "DOE Early Career Research",
    "grant_008": "RWJF Health Policy Fellows",
    "grant_009": "NEA Art Works Grant",
    "grant_010": "Google.org Impact Challenge",
}

# ---------------------------------------------------------------------------
# Workflow diagram (text-art, rendered once at the top of the page)
# ---------------------------------------------------------------------------

WORKFLOW_DIAGRAM = """\
```
Chat Input
    │
    ├──── Grant Search Agent  ────┐
    │     (RAG + Granite)         │
    │                             │
    ├──── Eligibility Agent  ─────┤   Agent Router ──► Chat Output
    │     (RAG + Granite)         │
    │                             │
    ├──── Funding Info Agent ─────┤
    │     (RAG + Granite)         │
    │                             │
    └──── Proposal Draft Agent ───┘
          (RAG + Granite)

Shared components:
  ChromaDB Vector Store  ◄──  RAG Retriever  ──►  all four agents
  IBM Granite (watsonx.ai)  ──────────────────────►  all four agents
```
"""


# ---------------------------------------------------------------------------
# Helper: load the workflow JSON for display
# ---------------------------------------------------------------------------

def _load_workflow_meta() -> dict[str, Any]:
    """Load metadata from langflow_workflow.json."""
    path = Path("langflow_workflow.json")
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------

def _render_workflow_overview() -> None:
    """Render the workflow overview section."""
    meta = _load_workflow_meta()

    st.markdown(
        "This page exposes the **LangFlow multi-agent workflow** defined in "
        "[`langflow_workflow.json`](langflow_workflow.json).  "
        "Each tab invokes one of the four specialist agents through "
        "`src/langflow/workflow.py`."
    )

    with st.expander("🗺️ Workflow Architecture", expanded=True):
        st.markdown(WORKFLOW_DIAGRAM)

    if meta:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Agents", "4")
        with col2:
            st.metric("LangFlow Nodes", str(len(meta.get("data", {}).get("nodes", []))))
        with col3:
            st.metric("Edges", str(len(meta.get("data", {}).get("edges", []))))

        with st.expander("📋 Agent Routes"):
            routes = meta.get("meta", {}).get("agent_routes", {})
            for route, desc in routes.items():
                st.markdown(f"- **`{route}`** — {desc}")

        with st.expander("🔑 Environment Variables"):
            env_vars = meta.get("meta", {}).get("environment_variables", {})
            for var, purpose in env_vars.items():
                st.markdown(f"- `{var}` — {purpose}")

    with st.expander("📄 View langflow_workflow.json"):
        if meta:
            st.json(meta)
        else:
            st.warning("`langflow_workflow.json` not found in the workspace root.")


def _render_search_tab() -> None:
    """Tab: Grant Search Agent."""
    st.subheader("🔍 Grant Search Agent")
    st.caption(
        "LangFlow path: **Chat Input → RAG Retriever (ChromaDB) → "
        "IBM Granite → Chat Output**"
    )
    st.markdown(
        "Describe what you are looking for. The Search Agent performs semantic "
        "retrieval over ChromaDB and uses IBM Granite to summarise the best matches."
    )

    with st.form("lf_search_form"):
        query = st.text_area(
            "Search Query",
            placeholder=(
                "e.g. 'Funding for a nonprofit working on climate resilience "
                "in underserved coastal communities'"
            ),
            height=110,
        )
        n_results = st.slider("Number of results", min_value=1, max_value=10, value=5)
        submitted = st.form_submit_button("🔍 Run Grant Search Agent", type="primary")

    if submitted and query.strip():
        with st.spinner("Running Grant Search Agent via LangFlow workflow…"):
            from src.langflow.workflow import run_workflow
            result = run_workflow("search", query=query.strip(), n_results=n_results)

        st.success("**Chat Output — Grant Search Agent**")
        st.markdown(result["output"])

        if result.get("grants"):
            st.subheader(f"Retrieved Grants ({len(result['grants'])})")
            for g in result["grants"]:
                with st.expander(f"**{g['title']}** — {g['funder']}"):
                    cols = st.columns(2)
                    with cols[0]:
                        st.markdown(f"**Amount:** ${int(g['amount_min']):,} – ${int(g['amount_max']):,}")
                        st.markdown(f"**Deadline:** {g['deadline']}")
                    with cols[1]:
                        st.markdown(f"**Categories:** {g['categories']}")
                        st.markdown(f"**Focus Areas:** {g['focus_areas']}")
                    if g.get("application_url"):
                        st.markdown(f"[🔗 Apply Here]({g['application_url']})")

    elif submitted:
        st.warning("Please enter a search query.")


def _render_eligibility_tab() -> None:
    """Tab: Eligibility Agent."""
    st.subheader("✅ Eligibility Agent")
    st.caption(
        "LangFlow path: **Chat Input → RAG Retriever (ChromaDB) → "
        "IBM Granite → Chat Output**"
    )
    st.markdown(
        "Select a grant and fill in your organisation profile. "
        "The Eligibility Agent returns a structured verdict with reasons and a recommendation."
    )

    grant_id = st.selectbox(
        "Target Grant",
        options=list(GRANT_OPTIONS.keys()),
        format_func=lambda k: f"{k} — {GRANT_OPTIONS[k]}",
        key="lf_elig_grant",
    )

    with st.form("lf_eligibility_form"):
        col1, col2 = st.columns(2)
        with col1:
            org_type     = st.selectbox("Organisation Type",
                ["nonprofit", "small business", "startup", "university",
                 "research institution", "tribal government", "individual researcher", "other"])
            for_profit   = st.checkbox("For-profit entity")
            us_based     = st.checkbox("US-based", value=True)
            employee_count = st.number_input("Employee Count", min_value=0, value=10)
        with col2:
            focus_areas_text = st.text_input("Focus Areas (comma-separated)",
                placeholder="e.g. climate justice, water quality")
            description = st.text_area("Organisation Description",
                placeholder="Briefly describe your organisation and mission.",
                height=110)

        submitted = st.form_submit_button("✅ Run Eligibility Agent", type="primary")

    if submitted:
        profile = {
            "org_type":      org_type,
            "for_profit":    for_profit,
            "us_based":      us_based,
            "employee_count": employee_count,
            "focus_areas":   [f.strip() for f in focus_areas_text.split(",") if f.strip()],
            "description":   description,
        }
        with st.spinner("Running Eligibility Agent via LangFlow workflow…"):
            from src.langflow.workflow import run_workflow
            result = run_workflow("eligibility", grant_id=grant_id, profile=profile)

        eligible   = result.get("eligible")
        confidence = result.get("confidence", "low")

        if eligible is True:
            st.success(f"**Chat Output** — ✅ Likely Eligible (Confidence: {confidence})")
        elif eligible is False:
            st.error(f"**Chat Output** — ❌ Likely Not Eligible (Confidence: {confidence})")
        else:
            st.warning("**Chat Output** — ⚠️ Eligibility undetermined. Manual review recommended.")

        st.markdown(result["output"])


def _render_funding_info_tab() -> None:
    """Tab: Funding Information Agent."""
    st.subheader("📋 Funding Information Agent")
    st.caption(
        "LangFlow path: **Chat Input → RAG Retriever (ChromaDB) → "
        "IBM Granite → Chat Output**"
    )
    st.markdown(
        "Select a grant to receive a comprehensive AI-generated briefing covering "
        "funding amounts, deadlines, eligibility, application tips, and pitfalls."
    )

    grant_id = st.selectbox(
        "Select Grant",
        options=list(GRANT_OPTIONS.keys()),
        format_func=lambda k: f"{k} — {GRANT_OPTIONS[k]}",
        key="lf_info_grant",
    )

    if st.button("📋 Run Funding Info Agent", type="primary"):
        with st.spinner("Running Funding Information Agent via LangFlow workflow…"):
            from src.langflow.workflow import run_workflow
            result = run_workflow("info", grant_id=grant_id)

        grant = result.get("grant")
        if grant:
            cols = st.columns(3)
            with cols[0]:
                st.metric("Min Amount", f"${grant['amount_min']:,}")
            with cols[1]:
                st.metric("Max Amount", f"${grant['amount_max']:,}")
            with cols[2]:
                st.metric("Deadline", grant["deadline"])

        st.success("**Chat Output — Funding Information Agent**")
        st.markdown(result["output"])

        if grant and grant.get("application_url"):
            st.markdown(f"[🔗 Official Application Page]({grant['application_url']})")


def _render_proposal_tab() -> None:
    """Tab: Proposal Draft Agent."""
    st.subheader("✍️ Proposal Draft Agent")
    st.caption(
        "LangFlow path: **Chat Input → RAG Retriever (ChromaDB) → "
        "IBM Granite → Chat Output**"
    )
    st.markdown(
        "Select a target grant and describe your organisation. "
        "The Proposal Draft Agent generates a tailored 10-section proposal outline."
    )

    grant_id = st.selectbox(
        "Target Grant",
        options=list(GRANT_OPTIONS.keys()),
        format_func=lambda k: f"{k} — {GRANT_OPTIONS[k]}",
        key="lf_prop_grant",
    )

    with st.form("lf_proposal_form"):
        col1, col2 = st.columns(2)
        with col1:
            org_name    = st.text_input("Organisation Name", placeholder="e.g. GreenComm Initiative")
            org_type    = st.selectbox("Organisation Type",
                ["nonprofit", "small business", "startup", "university",
                 "research institution", "other"])
            team_size   = st.number_input("Team Size", min_value=1, value=10)
            budget_cap  = st.text_input("Annual Budget / Capacity",
                placeholder="e.g. $500,000 per year")
        with col2:
            mission     = st.text_area("Mission Statement",
                placeholder="Our mission is to…", height=70)
            key_projects = st.text_area("Key Projects (one per line)",
                placeholder="Air quality monitoring\nYouth STEM programme", height=70)
            strengths   = st.text_area("Organisational Strengths (one per line)",
                placeholder="10 years community experience\nEstablished partnerships", height=70)
            geo_focus   = st.text_input("Geographic Focus",
                placeholder="e.g. Southeast US, Global")

        submitted = st.form_submit_button("✍️ Run Proposal Draft Agent", type="primary")

    if submitted:
        profile = {
            "org_name":        org_name or "Unnamed Organisation",
            "org_type":        org_type,
            "mission":         mission,
            "key_projects":    [p.strip() for p in key_projects.splitlines() if p.strip()],
            "strengths":       [s.strip() for s in strengths.splitlines() if s.strip()],
            "budget_capacity": budget_cap,
            "team_size":       team_size,
            "geographic_focus": geo_focus,
        }
        with st.spinner("Running Proposal Draft Agent via LangFlow workflow…"):
            from src.langflow.workflow import run_workflow
            result = run_workflow("proposal", grant_id=grant_id, profile=profile)

        grant = result.get("grant")
        if grant:
            st.info(
                f"**Target Grant:** {grant['title']} | **Funder:** {grant['funder']} | "
                f"**Amount:** ${grant['amount_min']:,}–${grant['amount_max']:,}"
            )

        st.success("**Chat Output — Proposal Draft Agent**")
        st.markdown(result["output"])

        if result.get("outline"):
            st.download_button(
                label="⬇️ Download Proposal Outline (.md)",
                data=result["outline"],
                file_name=f"proposal_outline_{grant_id}.md",
                mime="text/markdown",
            )


# ---------------------------------------------------------------------------
# Public entry-point
# ---------------------------------------------------------------------------

def render() -> None:
    """
    Render the LangFlow Workflow page inside the Streamlit app.

    Call this from app.py when the user selects the LangFlow page from the
    sidebar navigation.
    """
    st.title("⚡ LangFlow Workflow")
    st.markdown(
        "**AI Grant Funding Finder** — four specialist agents connected through a "
        "modular LangFlow workflow backed by IBM Granite (watsonx.ai) and "
        "ChromaDB RAG retrieval."
    )

    _render_workflow_overview()
    st.divider()

    tab_search, tab_elig, tab_info, tab_prop = st.tabs([
        "🔍 Grant Search",
        "✅ Eligibility Check",
        "📋 Funding Info",
        "✍️ Proposal Draft",
    ])

    with tab_search:
        _render_search_tab()
    with tab_elig:
        _render_eligibility_tab()
    with tab_info:
        _render_funding_info_tab()
    with tab_prop:
        _render_proposal_tab()
