"""
LangFlow workflow bridge — AI Grant Funding Finder
====================================================
Maps the four LangFlow agent routes defined in langflow_workflow.json to
the existing Python agent implementations in src/agents/*.

Usage
-----
    from src.langflow.workflow import run_workflow

    # Grant Search
    result = run_workflow("search", query="rural health nonprofits in Southeast US")

    # Eligibility Check
    result = run_workflow(
        "eligibility",
        grant_id="grant_001",
        profile={"org_type": "nonprofit", "us_based": True, ...}
    )

    # Funding Info
    result = run_workflow("info", grant_id="grant_002")

    # Proposal Draft
    result = run_workflow(
        "proposal",
        grant_id="grant_005",
        profile={"org_name": "GreenComm", "mission": "...", ...}
    )

Agent route map
---------------
    "search"      →  Grant Search Agent      (src/agents/search_agent.py)
    "eligibility" →  Eligibility Agent       (src/agents/eligibility_agent.py)
    "info"        →  Funding Information Agent (src/agents/funding_info_agent.py)
    "proposal"    →  Proposal Draft Agent    (src/agents/proposal_agent.py)

Component stack (mirrors langflow_workflow.json)
-------------------------------------------------
    Chat Input  ──►  Agent Router
                          ├─► Grant Search Agent  ──► RAG Retriever ──► ChromaDB
                          ├─► Eligibility Agent   ──► RAG Retriever ──► ChromaDB
                          ├─► Funding Info Agent  ──► RAG Retriever ──► ChromaDB
                          └─► Proposal Draft Agent ─► RAG Retriever ──► ChromaDB
                     IBM Granite (watsonx.ai)  ──► all four agents
                     Agent Router  ──►  Chat Output
"""

from __future__ import annotations

import logging
from typing import Any, Literal

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Public type alias
# ---------------------------------------------------------------------------

AgentRoute = Literal["search", "eligibility", "info", "proposal"]

# ---------------------------------------------------------------------------
# Component: Chat Input (LangFlow node: chat_input)
# ---------------------------------------------------------------------------

def build_chat_input(
    route: AgentRoute,
    *,
    query: str = "",
    grant_id: str = "",
    profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Construct the structured message that Chat Input passes into the workflow.

    The message format mirrors the ``input_value`` consumed by each agent's
    system_prompt template in langflow_workflow.json.
    """
    return {
        "route":    route,
        "query":    query,
        "grant_id": grant_id,
        "profile":  profile or {},
    }


# ---------------------------------------------------------------------------
# Component: Agent Router (LangFlow node: agent_router)
# ---------------------------------------------------------------------------

def route_to_agent(chat_input: dict[str, Any]) -> dict[str, Any]:
    """
    Conditional router — selects and invokes the correct specialist agent.

    Mirrors the ``route_map`` in the agent_router LangFlow node.

    Returns the raw result dict produced by the agent.
    """
    route: AgentRoute = chat_input["route"]

    if route == "search":
        return _run_search(chat_input)
    if route == "eligibility":
        return _run_eligibility(chat_input)
    if route == "info":
        return _run_funding_info(chat_input)
    if route == "proposal":
        return _run_proposal(chat_input)

    raise ValueError(
        f"Unknown agent route '{route}'. "
        "Valid routes: 'search', 'eligibility', 'info', 'proposal'."
    )


# ---------------------------------------------------------------------------
# Component: Grant Search Agent (LangFlow node: grant_search_agent)
# RAG Retriever + ChromaDB + IBM Granite
# ---------------------------------------------------------------------------

def _run_search(chat_input: dict[str, Any]) -> dict[str, Any]:
    """
    Grant Search Agent.

    LangFlow components used:
      Chat Input → RAG Retriever (ChromaDB) → IBM Granite → Chat Output

    Delegates to src/agents/search_agent.py which runs:
      1. ChromaDB semantic retrieval  (src/indexing/rag_pipeline.query_grants)
      2. IBM Granite summary           (src/utils/llm.GraniteClient.generate)
    """
    from src.agents.search_agent import run_search_agent

    query    = chat_input.get("query", "")
    n_results = chat_input.get("n_results", 5)

    if not query:
        return {
            "agent":   "grant_search_agent",
            "output":  "Please provide a search query.",
            "grants":  [],
            "summary": "",
        }

    logger.info("[LangFlow:GrantSearchAgent] query=%s  n_results=%s", query, n_results)
    result = run_search_agent(query, n_results=n_results)

    return {
        "agent":   "grant_search_agent",
        "output":  result["summary"],
        "grants":  result["grants"],
        "summary": result["summary"],
    }


# ---------------------------------------------------------------------------
# Component: Eligibility Agent (LangFlow node: eligibility_agent)
# RAG Retriever + ChromaDB + IBM Granite
# ---------------------------------------------------------------------------

def _run_eligibility(chat_input: dict[str, Any]) -> dict[str, Any]:
    """
    Eligibility Agent.

    LangFlow components used:
      Chat Input → RAG Retriever (ChromaDB) → IBM Granite → Chat Output

    Delegates to src/agents/eligibility_agent.py which:
      1. Loads grant criteria from the raw JSON dataset
      2. Calls IBM Granite with a structured eligibility prompt
      3. Parses and returns a JSON verdict
    """
    from src.agents.eligibility_agent import run_eligibility_agent

    grant_id = chat_input.get("grant_id", "")
    profile  = chat_input.get("profile", {})

    if not grant_id:
        return {
            "agent":  "eligibility_agent",
            "output": "Please provide a grant_id.",
            "eligible": None,
            "confidence": "low",
            "reasons": [],
            "warnings": [],
            "recommendation": "",
        }

    logger.info("[LangFlow:EligibilityAgent] grant_id=%s", grant_id)
    result = run_eligibility_agent(grant_id, profile)

    # Build a human-readable Chat Output string
    status = "✅ Eligible" if result.get("eligible") else "❌ Not Eligible"
    output = (
        f"**{status}** (Confidence: {result.get('confidence', 'low')})\n\n"
        + "\n".join(f"- {r}" for r in result.get("reasons", []))
    )
    if result.get("warnings"):
        output += "\n\n**Warnings:**\n" + "\n".join(
            f"- ⚠️ {w}" for w in result["warnings"]
        )
    output += f"\n\n💡 {result.get('recommendation', '')}"

    return {
        "agent":          "eligibility_agent",
        "output":         output,
        **result,
    }


# ---------------------------------------------------------------------------
# Component: Funding Information Agent (LangFlow node: funding_info_agent)
# RAG Retriever + ChromaDB + IBM Granite
# ---------------------------------------------------------------------------

def _run_funding_info(chat_input: dict[str, Any]) -> dict[str, Any]:
    """
    Funding Information Agent.

    LangFlow components used:
      Chat Input → RAG Retriever (ChromaDB) → IBM Granite → Chat Output

    Delegates to src/agents/funding_info_agent.py which:
      1. Loads the full grant record
      2. Calls IBM Granite with a briefing prompt covering 6 structured sections
    """
    from src.agents.funding_info_agent import run_funding_info_agent

    grant_id = chat_input.get("grant_id", "")

    if not grant_id:
        return {
            "agent":   "funding_info_agent",
            "output":  "Please provide a grant_id.",
            "grant":   None,
            "briefing": "",
        }

    logger.info("[LangFlow:FundingInfoAgent] grant_id=%s", grant_id)
    result = run_funding_info_agent(grant_id)

    return {
        "agent":    "funding_info_agent",
        "output":   result["briefing"],
        "grant":    result["grant"],
        "briefing": result["briefing"],
    }


# ---------------------------------------------------------------------------
# Component: Proposal Draft Agent (LangFlow node: proposal_draft_agent)
# RAG Retriever + ChromaDB + IBM Granite
# ---------------------------------------------------------------------------

def _run_proposal(chat_input: dict[str, Any]) -> dict[str, Any]:
    """
    Proposal Draft Agent.

    LangFlow components used:
      Chat Input → RAG Retriever (ChromaDB) → IBM Granite → Chat Output

    Delegates to src/agents/proposal_agent.py which:
      1. Loads the target grant record
      2. Calls IBM Granite with a 10-section proposal outline prompt
    """
    from src.agents.proposal_agent import run_proposal_agent

    grant_id = chat_input.get("grant_id", "")
    profile  = chat_input.get("profile", {})

    if not grant_id:
        return {
            "agent":   "proposal_draft_agent",
            "output":  "Please provide a grant_id.",
            "grant":   None,
            "outline": "",
        }

    logger.info("[LangFlow:ProposalDraftAgent] grant_id=%s", grant_id)
    result = run_proposal_agent(grant_id, profile)

    return {
        "agent":   "proposal_draft_agent",
        "output":  result["outline"],
        "grant":   result["grant"],
        "outline": result["outline"],
    }


# ---------------------------------------------------------------------------
# Public API: run_workflow
# ---------------------------------------------------------------------------

def run_workflow(
    route: AgentRoute,
    *,
    query: str = "",
    grant_id: str = "",
    profile: dict[str, Any] | None = None,
    n_results: int = 5,
) -> dict[str, Any]:
    """
    Execute the AI Grant Funding Finder LangFlow workflow.

    This is the single entry-point used by the Streamlit integration and any
    external caller.  It mirrors the end-to-end path described in
    ``langflow_workflow.json``:

        Chat Input → [RAG Retriever ↔ ChromaDB] + IBM Granite
                   → Specialist Agent → Agent Router → Chat Output

    Parameters
    ----------
    route : "search" | "eligibility" | "info" | "proposal"
        Which specialist agent to invoke.
    query : str
        Free-text search query (used by the ``search`` route).
    grant_id : str
        Target grant ID, e.g. ``"grant_001"`` (used by ``eligibility``,
        ``info``, ``proposal``).
    profile : dict
        Applicant / organisation profile (used by ``eligibility`` and
        ``proposal``).
    n_results : int
        Number of RAG results to retrieve (``search`` route only, default 5).

    Returns
    -------
    dict
        Agent-specific result dict that always contains:
          - ``"agent"``  : the agent node ID
          - ``"output"`` : the human-readable Chat Output string

        Plus route-specific keys:
          - search      → ``grants``, ``summary``
          - eligibility → ``eligible``, ``confidence``, ``reasons``,
                          ``warnings``, ``recommendation``
          - info        → ``grant``, ``briefing``
          - proposal    → ``grant``, ``outline``
    """
    logger.info("[LangFlow:Workflow] route=%s  grant_id=%s", route, grant_id)

    # ── LangFlow node: Chat Input ─────────────────────────────────────────
    chat_input = build_chat_input(
        route,
        query=query,
        grant_id=grant_id,
        profile=profile,
    )
    chat_input["n_results"] = n_results

    # ── LangFlow nodes: Agent Router → Specialist Agent ──────────────────
    result = route_to_agent(chat_input)

    # ── LangFlow node: Chat Output ────────────────────────────────────────
    # ``result["output"]`` is what Chat Output surfaces to the end-user.
    return result
