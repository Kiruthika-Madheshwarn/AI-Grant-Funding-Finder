"""
Token usage display helper for Streamlit.

Call ``display_token_usage(usage)`` after any agent invocation to render a
consistent token-usage widget.  When the client is in stub mode the widget
clearly says so instead of showing zeros or fabricated numbers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.utils.llm import TokenUsage


def display_token_usage(usage: "TokenUsage", *, label: str = "Token Usage") -> None:
    """
    Render a token-usage section in the active Streamlit page.

    Parameters
    ----------
    usage : TokenUsage
        The usage object returned alongside the agent's text result.
    label : str
        Optional heading shown above the metrics (default: "Token Usage").
    """
    import streamlit as st

    st.divider()
    st.caption(f"🔢 **{label}**")

    if usage.stub_mode:
        st.info(
            "**Token usage unavailable in Stub Mode.**  \n"
            "Connect IBM Granite via watsonx.ai (set `WATSONX_API_KEY` and "
            "`WATSONX_PROJECT_ID` in `.env`) to see real token counts.",
            icon="ℹ️",
        )
        return

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Input Tokens", f"{usage.input_tokens:,}")
    with col2:
        st.metric("Output Tokens", f"{usage.output_tokens:,}")
    with col3:
        st.metric("Total Tokens", f"{usage.total_tokens:,}")
