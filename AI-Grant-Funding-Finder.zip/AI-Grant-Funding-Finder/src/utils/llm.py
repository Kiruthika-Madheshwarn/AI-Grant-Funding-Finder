"""
Thin wrapper around IBM watsonx.ai (Granite) for text generation.
Falls back to a stub response when credentials are not configured,
so the UI remains navigable without live API keys.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from src.utils.config import CONFIG

logger = logging.getLogger(__name__)


@dataclass
class TokenUsage:
    """
    Token counts returned by a single IBM Granite generation call.

    Attributes
    ----------
    input_tokens  : Number of tokens in the prompt sent to the model.
    output_tokens : Number of tokens in the model's generated response.
    total_tokens  : Sum of input and output tokens.
    stub_mode     : True when the client is running without live credentials
                    — token counts are unavailable in this case (all None).
    """

    input_tokens: int | None
    output_tokens: int | None
    total_tokens: int | None
    stub_mode: bool = False

    # ------------------------------------------------------------------
    # Convenience constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_stub(cls) -> "TokenUsage":
        """Return an empty usage object that signals stub / offline mode."""
        return cls(input_tokens=None, output_tokens=None,
                   total_tokens=None, stub_mode=True)

    @classmethod
    def from_counts(cls, input_tokens: int, output_tokens: int) -> "TokenUsage":
        """Build a live usage object from raw counts returned by the API."""
        return cls(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            stub_mode=False,
        )


@dataclass
class GenerateResult:
    """
    Combined output of a single GraniteClient.generate() call.

    Attributes
    ----------
    text  : The generated text string.
    usage : Token usage for this call (counts are None in stub mode).
    """

    text: str
    usage: TokenUsage


class GraniteClient:
    """IBM Granite LLM client via watsonx.ai."""

    def __init__(self) -> None:
        self._model = None
        self._ready = False
        self._init_model()

    def _init_model(self) -> None:
        if not CONFIG.watsonx_api_key or CONFIG.watsonx_api_key == "your_ibm_watsonx_api_key_here":
            logger.warning(
                "WATSONX_API_KEY not set — running in stub mode. "
                "Set credentials in .env to enable live Granite responses."
            )
            return

        try:
            from ibm_watsonx_ai import Credentials
            from ibm_watsonx_ai.foundation_models import ModelInference
            from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams

            credentials = Credentials(
                url=CONFIG.watsonx_url,
                api_key=CONFIG.watsonx_api_key,
            )
            params = {
                GenParams.MAX_NEW_TOKENS: 1024,
                GenParams.MIN_NEW_TOKENS: 10,
                GenParams.TEMPERATURE: 0.3,
                GenParams.TOP_K: 50,
                GenParams.TOP_P: 0.9,
                GenParams.REPETITION_PENALTY: 1.1,
            }
            self._model = ModelInference(
                model_id=CONFIG.granite_model_id,
                credentials=credentials,
                project_id=CONFIG.watsonx_project_id,
                params=params,
            )
            self._ready = True
            logger.info("Granite model '%s' initialised.", CONFIG.granite_model_id)
        except Exception as exc:
            logger.error("Failed to initialise Granite model: %s", exc)

    def generate(self, system_prompt: str, user_prompt: str) -> GenerateResult:
        """
        Generate a response from Granite.

        Returns a GenerateResult containing the text and a TokenUsage object.
        In stub mode (no live credentials) the text is a descriptive placeholder
        and TokenUsage.stub_mode is True with all counts set to None.
        """
        if not self._ready or self._model is None:
            return self._stub_result(system_prompt, user_prompt)

        full_prompt = f"{system_prompt}\n\nUser: {user_prompt}\n\nAssistant:"
        try:
            # Use generate() (not generate_text()) to receive the full response
            # object, which contains token usage in results[0].
            response = self._model.generate(prompt=full_prompt)
            result_obj = response["results"][0]
            text = result_obj.get("generated_text", "").strip()
            usage = TokenUsage.from_counts(
                input_tokens=result_obj.get("input_token_count", 0),
                output_tokens=result_obj.get("generated_token_count", 0),
            )
            logger.info(
                "Granite token usage — input: %d  output: %d  total: %d",
                usage.input_tokens, usage.output_tokens, usage.total_tokens,
            )
            return GenerateResult(text=text, usage=usage)
        except Exception as exc:
            logger.error("Granite generation error: %s", exc)
            return GenerateResult(
                text=f"⚠️ Generation error: {exc}",
                usage=TokenUsage.from_stub(),
            )

    @staticmethod
    def _stub_result(system_prompt: str, user_prompt: str) -> GenerateResult:
        """Return a clearly labelled stub result when credentials are absent."""
        text = (
            "🔧 **Stub Mode** — IBM Granite credentials not configured.\n\n"
            "To enable live AI responses:\n"
            "1. Copy `.env.example` to `.env`\n"
            "2. Fill in `WATSONX_API_KEY` and `WATSONX_PROJECT_ID`\n"
            "3. Restart the app\n\n"
            f"*System context received ({len(system_prompt)} chars), "
            f"user prompt received ({len(user_prompt)} chars).*"
        )
        return GenerateResult(text=text, usage=TokenUsage.from_stub())


_client: GraniteClient | None = None


def get_llm_client() -> GraniteClient:
    """Return a singleton GraniteClient instance."""
    global _client
    if _client is None:
        _client = GraniteClient()
    return _client
