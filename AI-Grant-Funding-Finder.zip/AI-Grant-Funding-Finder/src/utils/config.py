"""
Shared configuration and environment loading for AI Grant Funding Finder.
"""

import os
from dotenv import load_dotenv
from pydantic import BaseModel

load_dotenv()


class AppConfig(BaseModel):
    watsonx_api_key: str = ""
    watsonx_project_id: str = ""
    watsonx_url: str = "https://us-south.ml.cloud.ibm.com"
    granite_model_id: str = "ibm/granite-13b-instruct-v2"
    chroma_persist_dir: str = "./data/chroma_db"
    log_level: str = "INFO"


def load_config() -> AppConfig:
    """Load configuration from environment variables."""
    return AppConfig(
        watsonx_api_key=os.getenv("WATSONX_API_KEY", ""),
        watsonx_project_id=os.getenv("WATSONX_PROJECT_ID", ""),
        watsonx_url=os.getenv("WATSONX_URL", "https://us-south.ml.cloud.ibm.com"),
        granite_model_id=os.getenv("GRANITE_MODEL_ID", "ibm/granite-13b-instruct-v2"),
        chroma_persist_dir=os.getenv("CHROMA_PERSIST_DIR", "./data/chroma_db"),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )


CONFIG = load_config()
