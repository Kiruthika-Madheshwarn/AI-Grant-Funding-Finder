"""
RAG pipeline: ingests grant JSON data, creates embeddings,
and persists a ChromaDB vector store for retrieval.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any

import chromadb
from chromadb.utils import embedding_functions
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    from langchain.text_splitter import RecursiveCharacterTextSplitter  # type: ignore[no-redef]

from src.utils.config import CONFIG

logger = logging.getLogger(__name__)

COLLECTION_NAME = "grants"
RAW_DATA_PATH = Path("data/raw/sample_grants.json")


def _grant_to_document(grant: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """Convert a grant record to a plain-text document and metadata dict."""
    eligibility = grant.get("eligibility", {})
    org_types = ", ".join(eligibility.get("organization_types", []))
    categories = ", ".join(grant.get("categories", []))
    focus_areas = ", ".join(grant.get("focus_areas", []))

    text = (
        f"Title: {grant['title']}\n"
        f"Funder: {grant['funder']} ({grant['funder_type']})\n"
        f"Amount: ${grant['amount_min']:,} – ${grant['amount_max']:,} {grant['currency']}\n"
        f"Deadline: {grant['deadline']}\n"
        f"Categories: {categories}\n"
        f"Focus Areas: {focus_areas}\n"
        f"Eligible Organizations: {org_types}\n"
        f"US Based Required: {eligibility.get('us_based', False)}\n"
        f"For-Profit Allowed: {eligibility.get('for_profit', False)}\n"
        f"Match Required: {grant.get('match_required', False)}\n"
        f"Description: {grant['description']}"
    )

    metadata = {
        "id": grant["id"],
        "title": grant["title"],
        "funder": grant["funder"],
        "funder_type": grant["funder_type"],
        "amount_min": grant["amount_min"],
        "amount_max": grant["amount_max"],
        "deadline": grant["deadline"],
        "application_url": grant.get("application_url", ""),
        "for_profit": str(eligibility.get("for_profit", False)),
        "us_based": str(eligibility.get("us_based", True)),
        "match_required": str(grant.get("match_required", False)),
        "categories": categories,
        "focus_areas": focus_areas,
    }
    return text, metadata


def get_chroma_client() -> chromadb.PersistentClient:
    """Return a persistent ChromaDB client."""
    os.makedirs(CONFIG.chroma_persist_dir, exist_ok=True)
    return chromadb.PersistentClient(path=CONFIG.chroma_persist_dir)


def get_or_build_collection(force_rebuild: bool = False) -> chromadb.Collection:
    """
    Return the grants ChromaDB collection.
    Builds (or rebuilds) it from the raw JSON dataset if it does not exist.
    """
    client = get_chroma_client()
    ef = embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name="all-MiniLM-L6-v2"
    )

    if force_rebuild:
        try:
            client.delete_collection(COLLECTION_NAME)
            logger.info("Deleted existing collection for rebuild.")
        except Exception:
            pass

    existing = [c.name for c in client.list_collections()]
    if COLLECTION_NAME in existing:
        logger.info("Collection '%s' already exists — skipping ingest.", COLLECTION_NAME)
        return client.get_collection(name=COLLECTION_NAME, embedding_function=ef)

    logger.info("Building collection '%s' from %s …", COLLECTION_NAME, RAW_DATA_PATH)
    collection = client.create_collection(name=COLLECTION_NAME, embedding_function=ef)

    with open(RAW_DATA_PATH, "r", encoding="utf-8") as f:
        grants: list[dict[str, Any]] = json.load(f)

    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)

    ids, documents, metadatas = [], [], []
    for grant in grants:
        text, metadata = _grant_to_document(grant)
        chunks = splitter.split_text(text)
        for i, chunk in enumerate(chunks):
            ids.append(f"{grant['id']}_chunk_{i}")
            documents.append(chunk)
            metadatas.append(metadata)

    collection.add(ids=ids, documents=documents, metadatas=metadatas)
    logger.info("Ingested %d grants (%d chunks) into ChromaDB.", len(grants), len(ids))
    return collection


def query_grants(query_text: str, n_results: int = 5) -> list[dict[str, Any]]:
    """
    Semantic search over the grants collection.
    Returns a list of unique grant metadata dicts, ranked by relevance.
    """
    collection = get_or_build_collection()
    results = collection.query(query_texts=[query_text], n_results=n_results * 2)

    seen_ids: set[str] = set()
    unique_grants: list[dict[str, Any]] = []
    for meta in results["metadatas"][0]:
        grant_id = meta.get("id", "")
        if grant_id not in seen_ids:
            seen_ids.add(grant_id)
            unique_grants.append(meta)
        if len(unique_grants) >= n_results:
            break

    return unique_grants
