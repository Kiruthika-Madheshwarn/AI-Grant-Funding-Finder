"""
Search Agent — finds relevant grants using semantic RAG retrieval
and IBM Granite for query understanding and result summarisation.
"""

from __future__ import annotations

import logging
from typing import Any

from src.indexing.rag_pipeline import query_grants
from src.utils.llm import get_llm_client

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a grant search specialist. Given a user's query and a list of
retrieved grant opportunities, produce a concise, helpful summary that:
1. Highlights the most relevant grants for the user's needs.
2. Briefly explains WHY each grant is a good match.
3. Notes any key eligibility requirements the user should be aware of.
Keep the response professional and under 400 words."""


def run_search_agent(user_query: str, n_results: int = 5) -> dict[str, Any]:
    """
    Execute the Search Agent.

    Args:
        user_query: Free-text description of what the user is looking for.
        n_results:  Number of grant results to retrieve.

    Returns:
        {
            "grants":       list of grant metadata dicts,
            "summary":      Granite-generated summary string,
            "token_usage":  TokenUsage (counts are None in stub mode),
        }
    """
    logger.info("[SearchAgent] Query: %s", user_query)

    # Step 1 — RAG retrieval
    grants = query_grants(user_query, n_results=n_results)
    if not grants:
        from src.utils.llm import TokenUsage
        return {
            "grants": [],
            "summary": "No matching grants found for your query.",
            "token_usage": TokenUsage.from_stub(),
        }

    # Step 2 — Build context for Granite
    context_lines = []
    for i, g in enumerate(grants, 1):
        context_lines.append(
            f"{i}. {g['title']} ({g['funder']}) | "
            f"${int(g['amount_min']):,}–${int(g['amount_max']):,} | "
            f"Deadline: {g['deadline']} | "
            f"Categories: {g['categories']}"
        )
    context = "\n".join(context_lines)

    prompt = (
        f"User query: {user_query}\n\n"
        f"Retrieved grants:\n{context}\n\n"
        "Please summarise the most relevant opportunities for this user."
    )

    # Step 3 — Granite LLM summary
    llm = get_llm_client()
    result = llm.generate(system_prompt=SYSTEM_PROMPT, user_prompt=prompt)

    return {"grants": grants, "summary": result.text, "token_usage": result.usage}
