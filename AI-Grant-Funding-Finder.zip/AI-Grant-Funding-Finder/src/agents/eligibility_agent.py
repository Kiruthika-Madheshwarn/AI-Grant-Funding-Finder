"""
Eligibility Agent — evaluates whether a user/organisation is eligible
for a specific grant using IBM Granite reasoning over grant criteria.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from src.utils.llm import get_llm_client

logger = logging.getLogger(__name__)

RAW_DATA_PATH = Path("data/raw/sample_grants.json")

SYSTEM_PROMPT = """You are a grant eligibility specialist. Given an applicant profile and a
grant's eligibility requirements, carefully determine whether the applicant is eligible.

Respond in the following JSON format (no extra text):
{
  "eligible": true or false,
  "confidence": "high" | "medium" | "low",
  "reasons": ["reason 1", "reason 2", ...],
  "warnings": ["potential issue 1", ...],
  "recommendation": "A one-sentence recommendation."
}"""


def _load_grant_by_id(grant_id: str) -> dict[str, Any] | None:
    """Load a specific grant record from the raw dataset."""
    with open(RAW_DATA_PATH, "r", encoding="utf-8") as f:
        grants: list[dict[str, Any]] = json.load(f)
    for grant in grants:
        if grant["id"] == grant_id:
            return grant
    return None


def run_eligibility_agent(
    grant_id: str,
    applicant_profile: dict[str, Any],
) -> dict[str, Any]:
    """
    Evaluate eligibility for a given grant.

    Args:
        grant_id:          ID of the grant to evaluate (e.g. "grant_001").
        applicant_profile: Dict describing the applicant, e.g.:
            {
                "org_type": "nonprofit",
                "for_profit": False,
                "us_based": True,
                "employee_count": 12,
                "focus_areas": ["health equity", "community"],
                "description": "We run community health clinics in rural areas."
            }

    Returns:
        Parsed eligibility result dict with keys:
        eligible, confidence, reasons, warnings, recommendation.
    """
    logger.info("[EligibilityAgent] Checking grant %s", grant_id)

    grant = _load_grant_by_id(grant_id)
    if not grant:
        return {
            "eligible": False,
            "confidence": "high",
            "reasons": [f"Grant ID '{grant_id}' not found."],
            "warnings": [],
            "recommendation": "Please provide a valid grant ID.",
        }

    eligibility_criteria = json.dumps(grant["eligibility"], indent=2)
    grant_summary = (
        f"Title: {grant['title']}\n"
        f"Funder: {grant['funder']}\n"
        f"Categories: {', '.join(grant.get('categories', []))}\n"
        f"Focus Areas: {', '.join(grant.get('focus_areas', []))}\n"
        f"Eligibility Requirements:\n{eligibility_criteria}"
    )
    profile_text = json.dumps(applicant_profile, indent=2)

    prompt = (
        f"Grant:\n{grant_summary}\n\n"
        f"Applicant Profile:\n{profile_text}\n\n"
        "Evaluate whether this applicant is eligible for this grant. "
        "Respond only with valid JSON as specified."
    )

    llm = get_llm_client()
    generate_result = llm.generate(system_prompt=SYSTEM_PROMPT, user_prompt=prompt)
    raw_response = generate_result.text

    try:
        # Extract JSON from the response
        start = raw_response.find("{")
        end = raw_response.rfind("}") + 1
        result = json.loads(raw_response[start:end])
    except (json.JSONDecodeError, ValueError):
        logger.warning("[EligibilityAgent] Failed to parse LLM JSON response.")
        result = {
            "eligible": None,
            "confidence": "low",
            "reasons": ["Could not parse eligibility response. Please try again."],
            "warnings": [raw_response[:300]],
            "recommendation": "Manual review recommended.",
        }

    result["token_usage"] = generate_result.usage
    return result
