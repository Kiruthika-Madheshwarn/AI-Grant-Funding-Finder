"""
Funding Info Agent — provides deep-dive information about a specific grant,
including funding details, deadlines, requirements, and strategic tips,
powered by IBM Granite.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from src.utils.llm import get_llm_client

logger = logging.getLogger(__name__)

RAW_DATA_PATH = Path("data/raw/sample_grants.json")

SYSTEM_PROMPT = """You are a grant funding expert with deep knowledge of grant programmes.
Given full details of a grant, provide a comprehensive briefing that includes:
1. **Overview** – What this grant funds and why it matters.
2. **Funding Details** – Amount ranges, multi-year availability, match requirements.
3. **Key Deadlines & Timeline** – Application window and important dates.
4. **Eligibility Snapshot** – Who can apply (bullet points).
5. **Application Tips** – 3–5 practical tips for a strong application.
6. **Potential Pitfalls** – Common mistakes to avoid.
Be professional, clear, and actionable. Use markdown headers and bullet points."""


def _load_grant_by_id(grant_id: str) -> dict[str, Any] | None:
    """Load a specific grant record from the raw dataset."""
    with open(RAW_DATA_PATH, "r", encoding="utf-8") as f:
        grants: list[dict[str, Any]] = json.load(f)
    for grant in grants:
        if grant["id"] == grant_id:
            return grant
    return None


def run_funding_info_agent(grant_id: str) -> dict[str, Any]:
    """
    Generate a comprehensive briefing for a specific grant.

    Args:
        grant_id: ID of the grant (e.g. "grant_002").

    Returns:
        {
            "grant": raw grant metadata dict,
            "briefing": Granite-generated markdown briefing string,
        }
    """
    logger.info("[FundingInfoAgent] Briefing for grant %s", grant_id)

    grant = _load_grant_by_id(grant_id)
    if not grant:
        return {
            "grant": None,
            "briefing": f"Grant ID '{grant_id}' not found in the dataset.",
        }

    grant_text = json.dumps(grant, indent=2)
    prompt = (
        f"Please provide a comprehensive briefing for the following grant:\n\n"
        f"{grant_text}"
    )

    llm = get_llm_client()
    result = llm.generate(system_prompt=SYSTEM_PROMPT, user_prompt=prompt)

    return {"grant": grant, "briefing": result.text, "token_usage": result.usage}
