"""
Proposal Agent — drafts a tailored grant proposal outline
using IBM Granite, based on the applicant's profile and the target grant.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from src.utils.llm import get_llm_client

logger = logging.getLogger(__name__)

RAW_DATA_PATH = Path("data/raw/sample_grants.json")

SYSTEM_PROMPT = """You are an expert grant writer with a track record of successful proposals.
Given a grant's requirements and an applicant's profile, draft a detailed proposal outline.

Structure the outline with the following sections (use markdown):
## 1. Executive Summary
## 2. Problem Statement
## 3. Project Description & Objectives
## 4. Methodology / Approach
## 5. Expected Outcomes & Impact
## 6. Evaluation Plan
## 7. Organisational Capacity & Team
## 8. Budget Overview
## 9. Sustainability Plan
## 10. Conclusion

For each section, provide 2–4 guiding sentences and bullet-point prompts the applicant
should address. Tailor every section specifically to the grant's focus areas and
the applicant's stated mission and strengths. Be concrete, persuasive, and grant-savvy."""


def _load_grant_by_id(grant_id: str) -> dict[str, Any] | None:
    """Load a specific grant record from the raw dataset."""
    with open(RAW_DATA_PATH, "r", encoding="utf-8") as f:
        grants: list[dict[str, Any]] = json.load(f)
    for grant in grants:
        if grant["id"] == grant_id:
            return grant
    return None


def run_proposal_agent(
    grant_id: str,
    applicant_profile: dict[str, Any],
) -> dict[str, Any]:
    """
    Draft a grant proposal outline for the given grant and applicant.

    Args:
        grant_id:          Target grant ID (e.g. "grant_005").
        applicant_profile: Applicant information dict, e.g.:
            {
                "org_name": "GreenComm Initiative",
                "org_type": "nonprofit",
                "mission": "Advance climate justice in underserved communities.",
                "key_projects": ["Air quality monitoring programme", "Youth STEM camps"],
                "strengths": ["Community trust", "10 years of field experience"],
                "budget_capacity": "$250,000 per year",
                "team_size": 18,
                "geographic_focus": "Southeast US"
            }

    Returns:
        {
            "grant": raw grant metadata dict,
            "outline": Granite-generated markdown proposal outline,
        }
    """
    logger.info("[ProposalAgent] Drafting proposal for grant %s", grant_id)

    grant = _load_grant_by_id(grant_id)
    if not grant:
        return {
            "grant": None,
            "outline": f"Grant ID '{grant_id}' not found in the dataset.",
        }

    grant_context = (
        f"Grant Title: {grant['title']}\n"
        f"Funder: {grant['funder']}\n"
        f"Focus Areas: {', '.join(grant.get('focus_areas', []))}\n"
        f"Amount: ${grant['amount_min']:,} – ${grant['amount_max']:,}\n"
        f"Description: {grant['description']}\n"
        f"Match Required: {grant.get('match_required', False)}"
    )
    profile_text = json.dumps(applicant_profile, indent=2)

    prompt = (
        f"Grant Details:\n{grant_context}\n\n"
        f"Applicant Profile:\n{profile_text}\n\n"
        "Draft a tailored grant proposal outline for this applicant targeting this grant."
    )

    llm = get_llm_client()
    result = llm.generate(system_prompt=SYSTEM_PROMPT, user_prompt=prompt)

    return {"grant": grant, "outline": result.text, "token_usage": result.usage}
