# AGENTS.md — AI Grant Funding Finder

This file provides guidance for AI coding agents (e.g. Bob, Copilot, Codex) working inside this repository. Read this file before making any changes.

---

## Project Overview

**AI Grant Funding Finder** is a tool that helps researchers, non-profits, and startups discover relevant grant and funding opportunities using AI-powered search and matching. It ingests funding data from public sources, indexes it, and surfaces the most relevant opportunities based on a user's profile or query.

---

## Repository Structure

```
.
├── src/
│   ├── ingestion/        # Data ingestion pipelines (scrapers, API clients)
│   ├── indexing/         # Embedding, vector store, and search index management
│   ├── matching/         # Relevance scoring and ranking logic
│   ├── api/              # REST/GraphQL API layer (routes, controllers)
│   ├── ui/               # Frontend (if applicable)
│   └── utils/            # Shared helpers and utilities
├── data/
│   ├── raw/              # Raw downloaded grant data (do not edit manually)
│   └── processed/        # Cleaned and normalized records
├── tests/
│   ├── unit/             # Unit tests — one file per module
│   └── integration/      # End-to-end and integration tests
├── scripts/              # One-off data migration and utility scripts
├── docs/                 # Architecture notes, API docs, ADRs
├── .env.example          # Environment variable template (never commit .env)
├── AGENTS.md             # This file
└── README.md
```

---

## Tech Stack

> Update this section as the stack is finalized.

| Layer         | Technology           |
|---------------|----------------------|
| Language      | Python 3.11+         |
| AI / Embeddings | OpenAI / LangChain |
| Vector Store  | Pinecone / ChromaDB  |
| API Framework | FastAPI              |
| Database      | PostgreSQL           |
| Frontend      | React (TypeScript)   |
| Testing       | pytest / Vitest      |
| CI            | GitHub Actions       |

---

## Development Commands

```bash
# Install dependencies
pip install -r requirements.txt

# Run the API server (development)
uvicorn src.api.main:app --reload

# Run all tests
pytest

# Run ingestion pipeline
python -m src.ingestion.run

# Lint
ruff check .

# Format
ruff format .
```

---

## Agent Instructions

### General Rules

1. **Read before editing.** Always read the relevant source files before modifying them. Do not guess at structure or content.
2. **Minimal changes.** Make the smallest change that satisfies the requirement. Do not refactor unrelated code.
3. **No secrets.** Never commit API keys, tokens, or credentials. Use `.env` and reference `.env.example` for new variables.
4. **Test your changes.** After any logic change, run the relevant test suite (`pytest` for Python, `npm test` / `vitest` for frontend) and confirm it passes before finishing.
5. **Follow existing style.** Match the code style of the file you are editing. Do not introduce a new formatter or linter without discussion.

### Where to Put New Code

| What you're building                  | Where it goes                      |
|---------------------------------------|------------------------------------|
| A new data source / scraper           | `src/ingestion/`                   |
| A new embedding or indexing strategy  | `src/indexing/`                    |
| Changes to relevance / ranking        | `src/matching/`                    |
| A new API endpoint                    | `src/api/routes/`                  |
| A shared utility / helper             | `src/utils/`                       |
| A one-off data script                 | `scripts/`                         |
| A new test                            | `tests/unit/` or `tests/integration/` |

### Naming Conventions

- **Files:** `snake_case.py` for Python, `kebab-case.ts` for TypeScript.
- **Classes:** `PascalCase`.
- **Functions / variables:** `snake_case` (Python) or `camelCase` (TypeScript).
- **Constants:** `UPPER_SNAKE_CASE`.
- **Tests:** Mirror the source path — `tests/unit/ingestion/test_scraper.py` tests `src/ingestion/scraper.py`.

### Environment Variables

All configuration is driven by environment variables. See `.env.example` for the full list. Key variables:

| Variable              | Purpose                                      |
|-----------------------|----------------------------------------------|
| `OPENAI_API_KEY`      | OpenAI API access for embeddings / chat      |
| `DATABASE_URL`        | PostgreSQL connection string                 |
| `VECTOR_STORE_URL`    | Vector store endpoint (Pinecone / Chroma)    |
| `GRANTS_GOV_API_KEY`  | Grants.gov API key for federal funding data  |

---

## Out of Scope for Agents

- Do **not** modify `data/raw/` files directly — they are managed by the ingestion pipeline.
- Do **not** change CI/CD workflow files (`.github/workflows/`) without explicit instruction.
- Do **not** upgrade major dependency versions without explicit instruction.
- Do **not** add new third-party dependencies without confirming they are approved.

---

## Getting Help

- Architecture decisions are recorded in `docs/adr/`.
- For questions about grant data sources, see `docs/data-sources.md`.
- For API schema documentation, see `docs/api.md`.
