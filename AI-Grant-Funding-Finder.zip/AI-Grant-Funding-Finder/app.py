"""
AI Grant Funding Finder — Streamlit Application
Powered by IBM Granite + RAG (ChromaDB + sentence-transformers)
"""

import json
import logging

import streamlit as st

logging.basicConfig(level="INFO")

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AI Grant Funding Finder",
    page_icon="💡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Sidebar navigation ────────────────────────────────────────────────────────
st.sidebar.image(
    "https://upload.wikimedia.org/wikipedia/commons/5/51/IBM_logo.svg",
    width=80,
)
st.sidebar.title("Grant Finder")
st.sidebar.caption("Powered by IBM Granite + RAG")

page = st.sidebar.radio(
    "Navigate",
    [
        "🏠 Home",
        "🔍 Search Grants",
        "✅ Eligibility Check",
        "📋 Funding Info",
        "✍️ Proposal Draft",
        "⚡ LangFlow Workflow",
    ],
)

st.sidebar.divider()
st.sidebar.markdown(
    "**Model:** `ibm/granite-13b-instruct-v2`  \n"
    "**Vector DB:** ChromaDB (local)  \n"
    "**Embeddings:** `all-MiniLM-L6-v2`"
)

# ── Grant ID helper (shared across pages) ────────────────────────────────────
GRANT_OPTIONS = {
    "grant_001": "NSF SBIR Phase I",
    "grant_002": "NIH R01 Research Grant",
    "grant_003": "USDA Rural Business Development",
    "grant_004": "Gates Grand Challenges Explorations",
    "grant_005": "EPA Environmental Justice",
    "grant_006": "Ford Foundation BUILD",
    "grant_007": "DOE Early Career Research",
    "grant_008": "RWJF Health Policy Fellows",
    "grant_009": "NEA Art Works Grant",
    "grant_010": "Google.org Impact Challenge",
}


# ─────────────────────────────────────────────────────────────────────────────
# PAGE: Home
# ─────────────────────────────────────────────────────────────────────────────
if page == "🏠 Home":
    st.title("💡 AI Grant Funding Finder")
    st.markdown(
        """
        Welcome to the **AI Grant Funding Finder** — an intelligent multi-agent system
        that helps researchers, nonprofits, and startups discover and pursue the right
        funding opportunities.

        Built with **IBM Granite** (via watsonx.ai) and a **Retrieval-Augmented Generation**
        pipeline backed by ChromaDB.
        """
    )

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.info("🔍 **Search Agent**\n\nSemantic search across 10 sample grants using RAG. Ask in plain English.")
    with col2:
        st.success("✅ **Eligibility Agent**\n\nPaste your org profile — Granite evaluates fit against grant criteria.")
    with col3:
        st.warning("📋 **Funding Info Agent**\n\nDeep-dive briefing on any grant: amounts, tips, pitfalls.")
    with col4:
        st.error("✍️ **Proposal Agent**\n\nAI-drafted proposal outline tailored to you and your target grant.")

    st.divider()
    st.subheader("Sample Dataset — 10 Grants Loaded")
    import json
    from pathlib import Path
    grants = json.loads(Path("data/raw/sample_grants.json").read_text())
    rows = [
        {
            "ID": g["id"],
            "Title": g["title"],
            "Funder": g["funder"],
            "Min ($)": f"${g['amount_min']:,}",
            "Max ($)": f"${g['amount_max']:,}",
            "Deadline": g["deadline"],
            "Type": g["funder_type"],
        }
        for g in grants
    ]
    st.dataframe(rows, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# PAGE: Search Grants
# ─────────────────────────────────────────────────────────────────────────────
elif page == "🔍 Search Grants":
    st.title("🔍 Search Grants")
    st.markdown(
        "Describe what you're looking for in plain English. "
        "The Search Agent will retrieve relevant grants and provide an AI-powered summary."
    )

    with st.form("search_form"):
        query = st.text_area(
            "Your query",
            placeholder=(
                "e.g. 'I'm a nonprofit focused on rural health equity in the southeast US "
                "and I need funding for a community water-quality programme.'"
            ),
            height=120,
        )
        n_results = st.slider("Number of results", min_value=1, max_value=10, value=5)
        submitted = st.form_submit_button("🔍 Search", type="primary")

    if submitted and query.strip():
        with st.spinner("Searching grants and generating summary…"):
            from src.agents.search_agent import run_search_agent
            result = run_search_agent(query.strip(), n_results=n_results)

        st.subheader("AI Summary")
        st.markdown(result["summary"])

        st.subheader(f"Top {len(result['grants'])} Matching Grants")
        for g in result["grants"]:
            with st.expander(f"**{g['title']}** — {g['funder']}"):
                col_a, col_b = st.columns(2)
                with col_a:
                    st.markdown(f"**Amount:** ${int(g['amount_min']):,} – ${int(g['amount_max']):,}")
                    st.markdown(f"**Deadline:** {g['deadline']}")
                    st.markdown(f"**Type:** {g['funder_type']}")
                with col_b:
                    st.markdown(f"**Categories:** {g['categories']}")
                    st.markdown(f"**Focus Areas:** {g['focus_areas']}")
                    st.markdown(f"**US Based Required:** {g['us_based']}")
                if g.get("application_url"):
                    st.markdown(f"[🔗 Apply Here]({g['application_url']})")

        from src.utils.token_display import display_token_usage
        display_token_usage(result["token_usage"])
    elif submitted:
        st.warning("Please enter a search query.")


# ─────────────────────────────────────────────────────────────────────────────
# PAGE: Eligibility Check
# ─────────────────────────────────────────────────────────────────────────────
elif page == "✅ Eligibility Check":
    st.title("✅ Eligibility Check")
    st.markdown(
        "Select a grant and fill in your organisation profile. "
        "The Eligibility Agent will assess your fit and flag any concerns."
    )

    grant_label = st.selectbox(
        "Select Grant",
        options=list(GRANT_OPTIONS.keys()),
        format_func=lambda k: f"{k} — {GRANT_OPTIONS[k]}",
    )

    st.subheader("Your Organisation Profile")
    col1, col2 = st.columns(2)
    with col1:
        org_type = st.selectbox(
            "Organisation Type",
            ["nonprofit", "small business", "startup", "university",
             "research institution", "tribal government", "individual researcher", "other"],
        )
        for_profit = st.checkbox("For-profit entity")
        us_based = st.checkbox("US-based", value=True)
        employee_count = st.number_input("Employee Count", min_value=0, value=10)
    with col2:
        focus_areas_text = st.text_input(
            "Focus Areas (comma-separated)",
            placeholder="e.g. climate justice, community health, water quality",
        )
        description = st.text_area(
            "Organisation Description",
            placeholder="Briefly describe your organisation, mission, and current projects.",
            height=120,
        )

    if st.button("✅ Check Eligibility", type="primary"):
        profile = {
            "org_type": org_type,
            "for_profit": for_profit,
            "us_based": us_based,
            "employee_count": employee_count,
            "focus_areas": [f.strip() for f in focus_areas_text.split(",") if f.strip()],
            "description": description,
        }
        with st.spinner("Evaluating eligibility…"):
            from src.agents.eligibility_agent import run_eligibility_agent
            result = run_eligibility_agent(grant_label, profile)

        eligible = result.get("eligible")
        confidence = result.get("confidence", "low")

        if eligible is True:
            st.success(f"✅ **Likely Eligible** (Confidence: {confidence})")
        elif eligible is False:
            st.error(f"❌ **Likely Not Eligible** (Confidence: {confidence})")
        else:
            st.warning("⚠️ Could not determine eligibility. Manual review recommended.")

        col_r, col_w = st.columns(2)
        with col_r:
            st.markdown("**Reasons:**")
            for r in result.get("reasons", []):
                st.markdown(f"- {r}")
        with col_w:
            if result.get("warnings"):
                st.markdown("**Warnings:**")
                for w in result.get("warnings", []):
                    st.markdown(f"- ⚠️ {w}")

        st.info(f"💡 **Recommendation:** {result.get('recommendation', '')}")

        from src.utils.token_display import display_token_usage
        display_token_usage(result["token_usage"])


# ─────────────────────────────────────────────────────────────────────────────
# PAGE: Funding Info
# ─────────────────────────────────────────────────────────────────────────────
elif page == "📋 Funding Info":
    st.title("📋 Funding Info")
    st.markdown(
        "Select any grant to receive an AI-generated deep-dive briefing — "
        "covering amounts, deadlines, application tips, and pitfalls to avoid."
    )

    grant_label = st.selectbox(
        "Select Grant",
        options=list(GRANT_OPTIONS.keys()),
        format_func=lambda k: f"{k} — {GRANT_OPTIONS[k]}",
    )

    if st.button("📋 Generate Briefing", type="primary"):
        with st.spinner("Generating funding briefing…"):
            from src.agents.funding_info_agent import run_funding_info_agent
            result = run_funding_info_agent(grant_label)

        grant = result.get("grant")
        if grant:
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Min Amount", f"${grant['amount_min']:,}")
            with col2:
                st.metric("Max Amount", f"${grant['amount_max']:,}")
            with col3:
                st.metric("Deadline", grant["deadline"])

        st.divider()
        st.markdown(result["briefing"])

        if grant and grant.get("application_url"):
            st.markdown(f"[🔗 Official Application Page]({grant['application_url']})")

        from src.utils.token_display import display_token_usage
        display_token_usage(result["token_usage"])


# ─────────────────────────────────────────────────────────────────────────────
# PAGE: Proposal Draft
# ─────────────────────────────────────────────────────────────────────────────
elif page == "✍️ Proposal Draft":
    st.title("✍️ Proposal Draft")
    st.markdown(
        "Select a target grant and describe your organisation. "
        "The Proposal Agent will draft a tailored proposal outline using IBM Granite."
    )

    grant_label = st.selectbox(
        "Target Grant",
        options=list(GRANT_OPTIONS.keys()),
        format_func=lambda k: f"{k} — {GRANT_OPTIONS[k]}",
    )

    st.subheader("Organisation Profile")
    col1, col2 = st.columns(2)
    with col1:
        org_name = st.text_input("Organisation Name", placeholder="e.g. GreenComm Initiative")
        org_type = st.selectbox(
            "Organisation Type",
            ["nonprofit", "small business", "startup", "university",
             "research institution", "other"],
        )
        team_size = st.number_input("Team Size", min_value=1, value=10)
        budget_capacity = st.text_input(
            "Annual Budget / Capacity",
            placeholder="e.g. $500,000 per year",
        )
    with col2:
        mission = st.text_area(
            "Mission Statement",
            placeholder="Our mission is to…",
            height=80,
        )
        key_projects = st.text_area(
            "Key Projects (one per line)",
            placeholder="Air quality monitoring\nYouth STEM programme",
            height=80,
        )
        strengths = st.text_area(
            "Organisational Strengths (one per line)",
            placeholder="10 years community experience\nEstablished partnerships",
            height=80,
        )
        geographic_focus = st.text_input(
            "Geographic Focus",
            placeholder="e.g. Southeast US, Global, Sub-Saharan Africa",
        )

    if st.button("✍️ Generate Proposal Outline", type="primary"):
        profile = {
            "org_name": org_name or "Unnamed Organisation",
            "org_type": org_type,
            "mission": mission,
            "key_projects": [p.strip() for p in key_projects.splitlines() if p.strip()],
            "strengths": [s.strip() for s in strengths.splitlines() if s.strip()],
            "budget_capacity": budget_capacity,
            "team_size": team_size,
            "geographic_focus": geographic_focus,
        }
        with st.spinner("Drafting proposal outline with IBM Granite…"):
            from src.agents.proposal_agent import run_proposal_agent
            result = run_proposal_agent(grant_label, profile)

        grant = result.get("grant")
        if grant:
            st.info(
                f"**Target Grant:** {grant['title']} | **Funder:** {grant['funder']} | "
                f"**Amount:** ${grant['amount_min']:,}–${grant['amount_max']:,}"
            )
        st.divider()
        st.markdown(result["outline"])

        st.download_button(
            label="⬇️ Download Outline (.md)",
            data=result["outline"],
            file_name=f"proposal_outline_{grant_label}.md",
            mime="text/markdown",
        )

        from src.utils.token_display import display_token_usage
        display_token_usage(result["token_usage"])


# ─────────────────────────────────────────────────────────────────────────────
# PAGE: LangFlow Workflow
# ─────────────────────────────────────────────────────────────────────────────
elif page == "⚡ LangFlow Workflow":
    from src.langflow.streamlit_integration import render as render_langflow
    render_langflow()
