"""
Unit tests for the 4 agents (stub / offline mode).
"""

import json
from unittest.mock import MagicMock, patch

# Pre-import agent modules so @patch decorator targets are resolvable.
import src.agents.search_agent  # noqa: F401
import src.agents.eligibility_agent  # noqa: F401
import src.agents.funding_info_agent  # noqa: F401
import src.agents.proposal_agent  # noqa: F401


# ── Search Agent ─────────────────────────────────────────────────────────────

@patch("src.agents.search_agent.get_llm_client")
@patch("src.agents.search_agent.query_grants")
def test_search_agent_returns_expected_keys(mock_query, mock_llm):
    """run_search_agent should return grants list and summary string."""
    mock_query.return_value = [
        {"id": "grant_001", "title": "NSF SBIR", "funder": "NSF",
         "amount_min": 50000, "amount_max": 275000,
         "deadline": "2025-09-15", "categories": "tech",
         "focus_areas": "AI", "funder_type": "federal"}
    ]
    mock_llm.return_value.generate.return_value = "Stub summary text."

    from src.agents.search_agent import run_search_agent
    result = run_search_agent("AI research funding for startups")

    assert "grants" in result
    assert "summary" in result
    assert isinstance(result["grants"], list)
    assert isinstance(result["summary"], str)


@patch("src.agents.search_agent.get_llm_client")
@patch("src.agents.search_agent.query_grants")
def test_search_agent_empty_results(mock_query, mock_llm):
    """run_search_agent should handle empty retrieval gracefully."""
    mock_query.return_value = []
    from src.agents.search_agent import run_search_agent
    result = run_search_agent("obscure query with no matches")
    assert result["grants"] == []
    assert "No matching" in result["summary"]


# ── Eligibility Agent ────────────────────────────────────────────────────────

@patch("src.agents.eligibility_agent.get_llm_client")
def test_eligibility_agent_invalid_grant(mock_llm):
    """run_eligibility_agent should handle a missing grant ID gracefully."""
    from src.agents.eligibility_agent import run_eligibility_agent
    result = run_eligibility_agent("grant_999", {"org_type": "nonprofit"})
    assert result["eligible"] is False
    assert "not found" in result["reasons"][0]


@patch("src.agents.eligibility_agent.get_llm_client")
def test_eligibility_agent_valid_grant(mock_llm):
    """run_eligibility_agent should call LLM and parse a valid JSON response."""
    mock_response = json.dumps({
        "eligible": True,
        "confidence": "high",
        "reasons": ["Org type matches"],
        "warnings": [],
        "recommendation": "Proceed with application."
    })
    mock_llm.return_value.generate.return_value = mock_response

    from src.agents.eligibility_agent import run_eligibility_agent
    result = run_eligibility_agent(
        "grant_001",
        {"org_type": "small business", "for_profit": True, "us_based": True,
         "employee_count": 50, "focus_areas": ["AI"], "description": "Tech startup."}
    )
    assert result["eligible"] is True
    assert result["confidence"] == "high"


# ── Funding Info Agent ───────────────────────────────────────────────────────

@patch("src.agents.funding_info_agent.get_llm_client")
def test_funding_info_agent_returns_briefing(mock_llm):
    """run_funding_info_agent should return a grant dict and briefing string."""
    mock_llm.return_value.generate.return_value = "## Overview\nThis is a great grant."

    from src.agents.funding_info_agent import run_funding_info_agent
    result = run_funding_info_agent("grant_002")

    assert result["grant"] is not None
    assert result["grant"]["id"] == "grant_002"
    assert "briefing" in result
    assert len(result["briefing"]) > 0


@patch("src.agents.funding_info_agent.get_llm_client")
def test_funding_info_agent_invalid_grant(mock_llm):
    """run_funding_info_agent should handle missing grant ID."""
    from src.agents.funding_info_agent import run_funding_info_agent
    result = run_funding_info_agent("grant_999")
    assert result["grant"] is None
    assert "not found" in result["briefing"]


# ── Proposal Agent ───────────────────────────────────────────────────────────

@patch("src.agents.proposal_agent.get_llm_client")
def test_proposal_agent_returns_outline(mock_llm):
    """run_proposal_agent should return a grant dict and outline string."""
    mock_llm.return_value.generate.return_value = "## 1. Executive Summary\nFill this in."

    from src.agents.proposal_agent import run_proposal_agent
    profile = {
        "org_name": "Test Org", "org_type": "nonprofit",
        "mission": "Help communities.", "key_projects": ["Project A"],
        "strengths": ["Experience"], "budget_capacity": "$100k",
        "team_size": 5, "geographic_focus": "US",
    }
    result = run_proposal_agent("grant_005", profile)

    assert result["grant"] is not None
    assert "outline" in result
    assert len(result["outline"]) > 0


@patch("src.agents.proposal_agent.get_llm_client")
def test_proposal_agent_invalid_grant(mock_llm):
    """run_proposal_agent should handle missing grant ID."""
    from src.agents.proposal_agent import run_proposal_agent
    result = run_proposal_agent("grant_999", {"org_name": "X"})
    assert result["grant"] is None
    assert "not found" in result["outline"]
