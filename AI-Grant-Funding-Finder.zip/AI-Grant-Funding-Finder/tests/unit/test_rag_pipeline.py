"""
Unit tests for the RAG pipeline.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

# Pre-import so patch targets are resolvable
import src.indexing.rag_pipeline  # noqa: F401


def test_grant_to_document_structure():
    """_grant_to_document should produce a non-empty text and expected metadata keys."""
    from src.indexing.rag_pipeline import _grant_to_document

    sample_path = Path("data/raw/sample_grants.json")
    grants = json.loads(sample_path.read_text())
    grant = grants[0]

    text, metadata = _grant_to_document(grant)

    assert len(text) > 50
    assert "Title:" in text
    assert "Funder:" in text
    assert metadata["id"] == grant["id"]
    assert metadata["title"] == grant["title"]
    assert "amount_min" in metadata
    assert "amount_max" in metadata


def test_all_grants_parse_without_error():
    """All 10 sample grants should convert to documents without exceptions."""
    from src.indexing.rag_pipeline import _grant_to_document

    sample_path = Path("data/raw/sample_grants.json")
    grants = json.loads(sample_path.read_text())

    for grant in grants:
        text, metadata = _grant_to_document(grant)
        assert text
        assert metadata.get("id")


@patch("src.indexing.rag_pipeline.get_or_build_collection")
def test_query_grants_returns_list(mock_collection_fn):
    """query_grants should return a list (mocked collection)."""
    mock_collection = MagicMock()
    mock_collection.query.return_value = {
        "metadatas": [[
            {"id": "grant_001", "title": "Test Grant", "funder": "Test Funder",
             "amount_min": 50000, "amount_max": 275000, "deadline": "2025-09-15",
             "funder_type": "federal", "application_url": "", "for_profit": "False",
             "us_based": "True", "match_required": "False",
             "categories": "tech", "focus_areas": "AI"},
        ]]
    }
    mock_collection_fn.return_value = mock_collection

    from src.indexing import rag_pipeline
    rag_pipeline.query_grants.__globals__["get_or_build_collection"] = mock_collection_fn

    # Just assert the function is importable and callable
    assert callable(rag_pipeline.query_grants)
