# AI Grant Funding Finder

An intelligent multi-agent system that helps researchers, nonprofits, and startups discover and pursue grant funding opportunities — powered by **IBM Granite** (via watsonx.ai) and a **Retrieval-Augmented Generation** pipeline.

---

## Architecture

```
User Query
    │
    ▼
┌─────────────────────────────────────────────┐
│              Streamlit UI (app.py)           │
└──────┬──────────┬──────────┬────────────────┘
       │          │          │          │
  Search      Eligibility  Funding   Proposal
  Agent        Agent       Info       Agent
       │          │        Agent        │
       └──────────┴──────────┴──────────┘
                       │
              RAG Pipeline (ChromaDB)
                       │
              IBM Granite (watsonx.ai)
```

### The 4 Agents

| Agent | File | Purpose |
|-------|------|---------|
| **Search** | `src/agents/search_agent.py` | Semantic RAG search + Granite-powered summary |
| **Eligibility** | `src/agents/eligibility_agent.py` | JSON-structured eligibility evaluation |
| **Funding Info** | `src/agents/funding_info_agent.py` | Deep-dive grant briefing with tips |
| **Proposal** | `src/agents/proposal_agent.py` | Tailored 10-section proposal outline |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Python 3.11+ |
| LLM | IBM Granite 13B Instruct v2 (via watsonx.ai) |
| Vector Store | ChromaDB (local persistent) |
| Embeddings | `sentence-transformers/all-MiniLM-L6-v2` |
| RAG Framework | LangChain |
| UI | Streamlit |
| Testing | pytest |

---

## Quick Start

### 1. Clone and install dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure environment variables

```bash
cp .env.example .env
# Edit .env and fill in your IBM watsonx.ai credentials
```

Required variables:

| Variable | Description |
|---|---|
| `WATSONX_API_KEY` | IBM watsonx.ai API key |
| `WATSONX_PROJECT_ID` | Your watsonx project ID |
| `WATSONX_URL` | watsonx endpoint (default: `https://us-south.ml.cloud.ibm.com`) |
| `GRANITE_MODEL_ID` | Granite model ID (default: `ibm/granite-13b-instruct-v2`) |

> **Note:** The app runs in **stub mode** if credentials are not set — all pages are navigable and the RAG retrieval works, but Granite responses will show a placeholder message.

### 3. Run the app

```bash
streamlit run app.py
```

---

## Project Structure

```
.
├── app.py                        # Streamlit entry point
├── requirements.txt
├── .env.example
├── data/
│   ├── raw/
│   │   └── sample_grants.json    # 10 sample grant records
│   └── chroma_db/                # Auto-created: ChromaDB vector store
├── src/
│   ├── agents/
│   │   ├── search_agent.py       # Agent 1: semantic grant search
│   │   ├── eligibility_agent.py  # Agent 2: eligibility evaluation
│   │   ├── funding_info_agent.py # Agent 3: grant deep-dive briefing
│   │   └── proposal_agent.py     # Agent 4: proposal outline generator
│   ├── indexing/
│   │   └── rag_pipeline.py       # ChromaDB ingestion + query
│   └── utils/
│       ├── config.py             # Environment config (pydantic)
│       └── llm.py                # Granite LLM client wrapper
└── tests/
    └── unit/
        ├── test_rag_pipeline.py
        └── test_agents.py
```

---

## Sample Dataset

`data/raw/sample_grants.json` contains **10 real-world grant types** spanning:

- Federal agencies (NSF, NIH, USDA, EPA, DOE, NEA)
- Private foundations (Gates, Ford, RWJF)
- Corporate philanthropy (Google.org)

Each record includes eligibility criteria, funding ranges, deadlines, focus areas, and application URLs.

---

## Adding More Grants

1. Add entries to `data/raw/sample_grants.json` following the existing schema.
2. Delete `data/chroma_db/` to force a re-index on next app start, or call `get_or_build_collection(force_rebuild=True)` in the Python REPL.

---

## Running Tests

```bash
pytest tests/
```

---

## Expanding the Project

| Goal | Where to add it |
|---|---|
| Scrape Grants.gov | `src/ingestion/` |
| Add Pinecone vector store | `src/indexing/` |
| Add a new agent | `src/agents/` |
| Add a REST API | `src/api/` |
| Add PostgreSQL persistence | `src/utils/` or `src/api/` |
